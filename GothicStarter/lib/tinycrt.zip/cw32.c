#define WIN32_LEAN_AND_MEAN
#include <windows.h>

void __cdecl WinMainCRTStartup(void)
{
	char *lpCmdLine = GetCommandLine();
	if (*lpCmdLine == '"')
	{
		while (*lpCmdLine && (*lpCmdLine != '"'))
			lpCmdLine++;
		if (*lpCmdLine == '"')
			lpCmdLine++;
	}
	else
		while (*lpCmdLine > ' ')
			lpCmdLine++;
	while (*lpCmdLine && (*lpCmdLine <= ' '))
		lpCmdLine++;

	ExitProcess(
		WinMain(GetModuleHandle(NULL), NULL, lpCmdLine, SW_SHOWDEFAULT));
}
